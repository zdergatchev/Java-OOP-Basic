package FootballTeamGenerator;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

public class Team {
//    private static final Map<String, Team> TEAMS = new HashMap<>(3);
//    public static void main(String[] args) throws IOExceprion {
//        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
//        String line = "";
//
//        while(!"END".equals(line = reader.readLine())){
//            String[] commandTokens = line.split(";");
//            String command = commandTokens[0];
//            String[] commandArgs =
//        }
//    }
}
