package FootballTeamGenerator;

public class Player {

}
