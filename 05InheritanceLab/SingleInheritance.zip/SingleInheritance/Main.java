package SingleInheritance;

public class Main {
    public static void main(String[] args) throws Exception {
       // BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        Dog dog = new Dog();
        dog.eat();
        dog.bark();
    }
}
